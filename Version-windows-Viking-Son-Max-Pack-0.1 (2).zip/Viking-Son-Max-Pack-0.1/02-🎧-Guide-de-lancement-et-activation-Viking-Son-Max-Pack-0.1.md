# 🎧 Guide de lancement et activation  
**Viking Son Max Pack 0.1**  
Forge audio libre signée Teknoïde 734 🛠️🔥⚔️  
**Version adaptée Escargot-Windows 11 🐌**

---

Ce guide vous explique comment :

- ✅ utiliser les scripts `.bat` du pack
- ✅ vérifier que tout est prêt à vibrer

Toutes les actions peuvent se faire **sans terminal**, ou via un simple terminal `cmd.exe` si vous le souhaitez.

---

## ✅ Viking Extracteur Max 0.1 – Lancement

🎯 Deux méthodes équivalentes :

### 🔹 1. Double-clic visuel recommandé :
Depuis le dossier du pack :

```
🛠️ Lanceur-Viking-Extracteur-Max.lnk
```

→ Ouvre un terminal vert fluo stylisé avec bannière  
→ Appelle automatiquement `Viking-Extracteur-Max.bat` dans le sous-dossier

### 🔹 2. Terminal à la main (optionnel) :
```cmd
cd /d Chemin\Vers\Viking-Son-Max-Pack-0.1
call ZX-Viking-Extracteur-Max-0.1\Viking-Extracteur-Max.bat
```

---

## ✅ Viking Séparateur Max 0.1 – Lancement

Même logique. À partir du dossier du pack :

```
⚔️ Lanceur-Viking-Separateur-Max.lnk
```

→ Appelle automatiquement `Viking-Separateur-Max.bat`  
→ S’appuie sur Demucs intégré au pack

---

## 📝 Astuces utiles

💡 Si une fenêtre s’ouvre puis se ferme aussitôt :
- Ouvrez le `.bat` à la main via `cmd.exe` pour lire le message
- Test avec :  
  ```cmd
  call Viking-Extracteur-Max.bat > debug.txt 2>&1
  ```

---

## 📌 Infos importantes


###  Escargot Shell (power-user) :
```cmd
cd /d Viking-Son-Max-Pack-0.1
call ZX-Viking-Extracteur-Max-0.1\Viking-Extracteur-Max.bat
call ZX-Viking-Separateur-Max-0.1-Script\Viking-Separateur-Max.bat
```

✔️ Dans les deux cas, les outils s’exécutent de manière portable et fiable

---

## ⚙️ Configuration personnalisée (facultatif)

Le fichier `config-viking.conf` est utilisé uniquement sur Linux.

ℹ️ Les `.bat` du pack Windows ne requièrent **aucune configuration préalable**.  
Tout est relié via chemins relatifs, prêt à fonctionner dans le dossier d’origine.

---

Un GROS coup de gueule vs windows c'est de la merde ! Trop de télémétrie, de surveillance et autre !!! Sans parler des applis en fond qui ralentisse tout ton système !!! Dons ici sur windows pas icones personnalisés pour le pack outils dites merci à windows les antis vrais artistes et créatifs... Ils ne pensent que à se mettre de la tune dans les poches !!! Sans se foutre un minimum de vous leur utilisateur de leurs services par défaut !!!
Merde ouvrez les yeux et passer a Linux c'est libre ! Open source ! Ouvert a tout et tous... C'est gratuit !!! Et vraiment open à tout le monde !

---

> 🧠 Tu es maintenant en possession d’un pack sonore complet, autonome, et qui respecte l’art du `.bat`.  
> Tu peux l’emmener sur une clé USB, le transmettre à la tribu, ou l’épingler à ta barre des tâches.



> Forge audio libre signée Teknoïde 734 — à utiliser sans modération, sauf sur Windows 😈️⚔️🔥⚔️😈️

