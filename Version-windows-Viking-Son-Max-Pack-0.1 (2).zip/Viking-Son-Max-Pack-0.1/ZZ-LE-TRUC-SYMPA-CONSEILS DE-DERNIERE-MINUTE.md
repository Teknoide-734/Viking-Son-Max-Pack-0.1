# 📦 Bonus de fin de raid — conseils malins & notes de terrain  
**Édition Escargot-Windows et Linux réunis autour du son brut et stylé** 🐌🐧🎧

---

## 🗃️ Range tes grimoires `.md` dans la crypte

Après lecture, place les fichiers `.md` dans :

```
ZX-Ressources\
```

🔒 Sous Windows comme sous Linux, ça garde le projet propre.  
Et puis c’est leur crypte. Ils y attendent en silence, prêts à être relus au prochain rituel.

---

## 🎥 Concernant `Viking-Extracteur-Max-0.1\Viking-Extracteur-Max-Entree`

- Tu peux glisser **plusieurs vidéos longues**, même de gros `.mp4`, `.webm`, `.mkv`
- L’outil les traite **une par une**, calmement, sans claquer
- Et bonus Escargot : même une vidéo cabossée peut ressortir **purifiée**

🪓 Si le résultat sonne mieux que l’original → **garde la version vikingisée, poubelle pour l’ancienne** 😈

---

## 🎧 Concernant `Viking-Separateur-Max-0.1\Viking-Separateur-Max-Entree`

- ⚠️ Évite les `.wav` trop longs (5 min max conseillé)  
  → **Demucs fatigue sur les sagas de 10 minutes**

- Pré-découpe avec **Audacity** (Windows/Linux) :  
  → 3 minutes de ton temps pour un `.wav` clean, net et séparable

- Tu peux balancer plusieurs fichiers `.wav` :  
  ➤ Ils seront séparés un par un, sans overlaps ni bugs

- 🔧 Chaque piste `.wav` est ensuite **réparée** pour éviter artefacts / distorsions

---

## 🖥️ Et pendant le rituel...

> 🧠 **Laisse la fenêtre du terminal ouverte** pendant toute la mission

Pourquoi ?  
Parce qu’à la fin tu verras apparaître :

```
✅ MISSION ACCOMPLIE
🎯 EXTRACTION TERMINÉE
➡️ VA À LA PROCHAINE PISTE
```

🔥 Bref, tu sais quand ça finit — et c’est stylé même sous Windows 11.

---

🧾 **Récap' express pour Escargot-Windows** :

- Range tes `.md` dans `ZX-Ressources\`
- Mets tes vidéos ou `.wav` dans les dossiers `Viking-Extracteur-Max-Entree\` ou `Viking-Separateur-Max-Entree\`
- Clique sur les `.lnk`, regarde le terminal, laisse-le parler
- 💥 Et admire les `.wav` tomber comme des trophées de guerre

> Terminal + son brut + interface qui claque = pas juste un outil : une expérience

---

## 🧪 Pour les bidouilleurs vaillants — bonus avancés

Tu veux modder comme un Berserker du `.bat` ? Ou un moine-scribe du `.sh` ?  
Voici de quoi creuser plus loin dans les scripts.

---

### 🎛️ Modifier la qualité ou le format de sortie avec FFmpeg

#### 🐧 Dans `Viking-Extracteur-Max.sh`  
#### 🪟 Dans `Viking-Extracteur-Max.bat`

Modifie cette ligne :

```bash
ffmpeg -i "input.mp4" -vn -acodec pcm_s16le "sortie.wav"
```

📦 Pour changer de codec :

- `libmp3lame` → `.mp3`
- `libvorbis` → `.ogg`
- `flac` → `.flac` sans perte

🛠️ N’oublie de changer aussi l’extension du fichier de sortie.

---

### 🧠 Activer les 4 ou 5 stems dans Demucs

Par défaut, séparation simple : voix + reste.

Mais tu peux forcer le mode multi-pistes 🎛️ :

```bash
demucs fichier.wav
```

Ou en `.bat` Windows :

```cmd
python -m demucs fichier.wav
```

Et pour un modèle précis :

```bash
demucs --model=htdemucs fichier.wav
```

📁 Résultat : un dossier `/separated/htdemucs/<fichier>/` avec :

- `vocals`
- `drums`
- `bass`
- `other`
- `noise` (si dispo)

⚠️ Attention : plus de pistes = plus de calculs = Windows Escargot qui ventile 🐌💨

---

## 🧠 Note importante

Tu peux éditer **les `.sh` avec Gedit, VSCodium, Nano, etc.**  
Et **les `.bat` sous Windows avec Bloc-notes ou Notepad++**

> 🔓 Fork, mod, skin, punkifie... mais reste stylé à TA façon.  
> Respecte la base, triture les modules. Et si tu partages : que ce soit épique 😈⚔️🔥

---

> “Ce que tu ne vois pas dans le menu, c’est pas bloqué.  
> C’est juste un potentiel à débloquer.”  
> — Sagesse Bash & Barbe Tressée

🎁 Ce pack n’est pas figé. C’est ton nouveau terrain de jeu sonore.
---

Un GROS coup de gueule vs windows c'est de la merde ! Trop de télémétrie, de surveillance et autre !!! Sans parler des applis en fond qui ralentisse tout ton système !!! Dons ici sur windows pas icones personnalisés pour le pack outils dites merci à windows les antis vrais artistes et créatifs... Ils ne pensent que à se mettre de la tune dans les poches !!! Sans se foutre un minimum de vous leur utilisateur de leurs services par défaut !!!
Merde ouvrez les yeux et passer a Linux c'est libre ! Open source ! Ouvert a tout et tous... C'est gratuit !!! Et vraiment open à tout le monde !

---

> Forge audio libre signée Teknoïde 734 — à utiliser sans modération… > … sauf sur Windows. > Parce que là-bas, tout est enregistré 😈⚔️🔥

