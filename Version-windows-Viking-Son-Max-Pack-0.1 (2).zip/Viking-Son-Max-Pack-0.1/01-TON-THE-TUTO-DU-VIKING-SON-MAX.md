# 🧾 TON-THE-TUTO-DU-VIKING-SON-MAX · Structure simple à copier

> 🛠️ Viking Son Max 0.1  

> ⚔️ Forge libre signée Teknoïde 734 – *édition multiplateforme désormais compatible Escargot-Windows™* 🐌

---

## 🗂️ Structure du tuto — Page par page (Linux + Windows)

### 📖 Page 2 — Introduction

- Présentation rapide : qu’est-ce que c’est

- Fonctionnement général (extraction + séparation)

- Aucun besoin d’installer un logiciel lourd

- Tout fonctionne en local, sans connexion Internet

- ✅ **Compatible Linux + Windows 11 Escargot**  
  *(avec `.sh`, `.desktop`, `.bat`, `.lnk`, et icônes personnalisées `.ico`)*

---

### 🛠️ Page 3 — Préparer le terrain

- Lister les dépendances :
  - 🎧 Linux : FFmpeg, Python, Demucs, terminal type Nemo/Thunar
  - 💻 Windows : `ffmpeg.exe` + `.bat` préconfigurés dans le pack

- ✅ **Sur Windows, aucune installation manuelle requise**  
  *(le pack contient tout, prêt à être lancé via double-clic)*

- Option d’ajouter des captures écran : Linux (`terminal + chmod`) / Windows (`explorateur + .lnk` décorés)

---

### 🗡️ Page 4 — Activer les scripts

- **Linux** : commandes `chmod +x` pour rendre `.sh` et `.desktop` exécutables  
- **Windows** : rien à activer. Les fichiers `.bat` et `.lnk` sont déjà prêts 💾

---

### 🚀 Page 5 — Lancer les outils

- **Méthode 1 (recommandée)** : double-clic `.lnk`
  - Linux : `.desktop` personnalisés avec icônes `.png`
  - Windows : `.lnk` associés à `.bat` + `.ico` multi-résolution

- **Méthode 2** : ouverture directe en terminal
  - Linux : `bash Lanceur-Viking-XXX.sh`
  - Windows : `cmd` → `call Lanceur-Viking-XXX.bat`

- Ajout possible de captures (ex : terminal Windows Escargot avec titre vert fluo et bannières punk 🪓)

---

### 🧩 Page 6 — Astuces et erreurs fréquentes

- `.desktop` qui ne lance pas ? → Linux : permissions / extension / gestionnaire de fichiers

- Demucs plante ? → Linux : venv mal activé ou audio trop long

- Windows : vérifier que `ffmpeg.exe` est bien dans le pack ou disponible dans `%PATH%`

- Et pour finir…  
  > *“Même un vieux papy-Windows en pantoufles peut extraire du son de furie si le chemin est clair.”* 🐌⚔️

---

💡 **Astuce mise en page PDF :**

Tu peux assembler tout ça dans **LibreOffice Writer** ou **WordPad** (sous Windows) :

- Colle chaque bloc de texte
- Ajoute des titres stylisés et encadrés
- Exporte en `.pdf` → ton tuto est prêt à être imprimé ou partagé

---

# ⚔️ Page 2 — Introduction (mise à jour Escargot-Windows 🐌)

Bienvenue dans le **Viking Son Max Pack 0.1** — un projet libre, léger, fun et brutalement efficace.  

Tu veux extraire une bande-son en `.wav` depuis une vidéo YouTube téléchargée ? Tu veux isoler la voix d’un chanteur ou choper la musique sans vocal ?  

Tu veux que ça marche **en local**, **sans cloud** et **sans logiciel lourdaud** ?  

💻 Tu es sur Windows 11 (Escargot Edition) ?  
Ce pack est ton compagnon de hache : **.bat** prêt à cliquer, **.lnk** illustrés, **.ico** décoratives, zéro terminal requis.

## 🎧 Deux outils t’attendent :

- **🌀 Viking-Extracteur-Max**  
  → Récupère la bande-son de **n’importe quelle vidéo** (même longue), en qualité `.wav` **HD berserker`  
  → Lancement via : `Lanceur-Viking-Extracteur-Max.lnk`  
  → Cible : `Viking-Extracteur-Max.bat`

- **🎙️ Viking-Séparateur-Max**  
  → Découpe **voix / instru** sur un fichier `.wav` grâce à **Demucs**, une IA dédiée à l’audio  
  ⚠️ À utiliser de préférence sur des fichiers courts (extraits, samples) pour éviter que Demucs sature.  
  ➕ Astuce : pré-découpe les morceaux longs avec **Audacity** sous Windows pour garder le contrôle.  
  → Lancement via : `Lanceur-Viking-Separateur-Max.lnk`  
  → Cible : `Viking-Separateur-Max.bat`

---

### ✅ Pourquoi ce pack est différent :

- Pas besoin d’installation complexe ou d’abonnement  
- Fonctionne **en local**, même sur une **clé USB**
- Utilisable même par un utilisateur débutant, **sans ligne de commande obligatoire**
- Style visuel, humour et efficacité 🧠🎛️

---

📌 **Note importante pour lancer les outils** :

### 🐧 Sous Linux :
```bash
cd /chemin/vers/Viking-Son-Max-Pack-0.1
bash Viking-Extracteur-Max.sh
```

---

✔️ Ça évite les erreurs de chemin et garantit que les scripts reconnaissent les ressources.

🧭 Tu lis ce tuto ? Alors tu viens d’armer ton premier pack audio comme un vrai Viking libre.

> À toi la séparation. À toi l’extraction.  
> Et que le `.wav` soit net, puissant, et stylé.

---

🛠️ Page 3 à suivre ? Tu n’as qu’à grogner, et je la sors de la forge. ⚡

---

Tu lis ce tuto ? C’est que t’as déjà commencé ton raid. Bienvenue à bord.

---

# 🛠️ Page 3 — Préparer le terrain (édition Escargot-Windows 🐌💻)

Avant de lancer la forge audio, il faut **s’assurer que les outils sont présents et bien huilés**.

### 💡 Bonne nouvelle : sur Escargot-Windows™, **aucune installation manuelle n’est requise si tu utilises le pack tel quel.**  
Tout a été **pré-packagé, branché et prêt à frapper**.

---

## 1. 🧰 FFmpeg — L’enclume de l’audio

Utilisé pour extraire les pistes son d’une vidéo, quel que soit son format.

- ✅ **Déjà fourni dans le dossier** `\Viking-Extracteur-Max-0.1\`
- 🎧 Utilisé automatiquement par les scripts `.bat`
- 🧪 Pour tester s’il fonctionne :

```cmd
cd /d Chemin\Vers\Viking-Son-Max-Pack-0.1
ffmpeg -version
```

Si une fenêtre noire clignote, c’est bon signe. Sinon, ajoute `ffmpeg.exe` dans le même dossier que tes `.bat`.

---

## 2. 🐍 Demucs — Le cerveau du split audio

Demucs (l'IA qui sépare voix / instru) est déjà intégré dans le dossier `\Viking-Separateur-Max-0.1\`.

Pas besoin d’environnement Python ou `pip` sur Windows :  
- ✔️ Les scripts `.bat` appellent directement l’instance portable embarquée
- ⛔ Aucun téléchargement extérieur
- 🔐 Fonctionne sans accès Internet

### 🛠️ Pour lancer l’outil :
Double-clique sur :
```
⚔️ Lanceur-Viking-Separateur-Max.lnk
```

---

## 3. 📁 Navigateur de fichiers

---

📌 Astuce bonus :

Le fichier `config-viking.conf` est ignoré sous Windows.  
Mais les chemins sont déjà calibrés dans les `.bat` — rien à modifier.

---

💥 Tout est prêt. Tu peux maintenant double-cliquer, écouter, splitter, extraire, grogner ou headbanger.  
Si ça claque dans les enceintes : **le pack fait honneur à ton casque.**

---

# 🛡️ Page 4 — Activer les scripts (édition Escargot-Windows 🐌)

Sous Escargot-Windows, pas besoin de rites d'exécution bash ou de droits chmod !  
Les scripts `.bat` et raccourcis `.lnk` sont déjà préparés, bénis, et prêts à être invoqués par double-clic.

---

## 🖱️ Méthode unique — Le double-clic des `.lnk`

Depuis le dossier `Viking-Son-Max-Pack-0.1`, ou son sous-dossier `ZX-Ressources\Lanceurs-Viking`, tu peux lancer :

- 🛠️ `Lanceur-Viking-Extracteur-Max.lnk`  
- ⚔️ `Lanceur-Viking-Separateur-Max.lnk`

Ces raccourcis `.lnk` sont décorés d’icônes `.ico` stylisées, et pointent vers leurs homologues `.bat` :

- `Viking-Extracteur-Max.bat` dans `\ZX-Viking-Extracteur-Max-0.1\`  
- `Viking-Separateur-Max.bat` dans `\ZX-Viking-Separateur-Max-0.1-Script\`

✅ Pas besoin de terminal. ✅ Pas besoin de droits admin.  
Juste **double-clic = lancement instantané** dans une console stylée.

---

# 🚀 Page 5 — Lancer les outils (version Windowsifiée)

Tu es prêt à briser du `.wav`. Il te suffit de cliquer.

---

## 🖱️ Méthode 1 : double-clic `.lnk` (recommandée pour Escargot-Users)

- 🛠️ `Lanceur-Viking-Extracteur-Max.lnk`  
   → Extraction audio `.wav` depuis vidéo `.mp4`, `.webm`, `.mkv`, etc.  
- ⚔️ `Lanceur-Viking-Separateur-Max.lnk`  
   → Séparation voix/instru via Demucs

Chaque `.lnk` ouvre un terminal Windows (`cmd.exe`) avec :
- ✅ Titre et couleurs personnalisés
- ✅ Pause finale pour lire le résultat
- ✅ Messages de log stylés made in Teknoïde

---

## 💻 Méthode 2 : terminal `cmd.exe` manuel (option hardcore 🧪)

Lancer les `.bat` directement avec `cmd` :

```cmd
cd /d Chemin\Vers\Viking-Son-Max-Pack-0.1
call ZX-Viking-Extracteur-Max-0.1\Viking-Extracteur-Max.bat
call ZX-Viking-Separateur-Max-0.1-Script\Viking-Separateur-Max.bat
```

---

📌 Astuce bonus :

🧩 Les `.lnk` peuvent être épinglés à la barre des tâches pour lancer ton split audio comme un vrai launcher d’artefact.

---

# ⚠️ Page 6 — Astuces & erreurs fréquentes (édition Windows 🐌)

Même avec des `.bat` parfaitement huilés, on peut croiser quelques trolls numériques.

---

## 🧪 “Demucs plante ou ferme immédiatement”

- Le fichier `.wav` est-il trop long ?  
  ➤ Privilégie des extraits de moins de 4–5 minutes pour éviter que ça mouline dans le vide

- Ouvre `Viking-Separateur-Max.bat` dans un terminal à la main pour lire les messages :

```cmd
cd /d Chemin\Vers\Viking-Son-Max-Pack-0.1
call ZX-Viking-Separateur-Max-0.1-Script\Viking-Separateur-Max.bat
```

---

## 🧩 “FFmpeg ne fonctionne pas”

- Vérifie que `ffmpeg.exe` est bien dans le dossier `Viking-Extracteur-Max-0.1`
- Test dans un terminal :

```cmd
ffmpeg -version
```

- Si la commande n'est pas reconnue : copie `ffmpeg.exe` au même endroit que le script `.bat`

---

## 🌀 Autres bugs bizarres ?

- Lance les scripts `.bat` via clic droit → **“Exécuter en tant qu’administrateur”** (rarement nécessaire, mais utile parfois si Windows bloque l’accès disque)
- Supprime les attributs “Protégé” de Windows (clic droit → “Propriétés” → décoche “Lire uniquement” ou “Provenance Internet”)
- Essaie sur une autre session utilisateur pour voir si le blocage est lié aux autorisations

---

💡 Pour loguer un diagnostic (output texte brut) :

```cmd
call Viking-Extracteur-Max.bat > debug.txt 2>&1
```

Tu peux ensuite ouvrir `debug.txt` dans Bloc-notes et chercher les anomalies.

---
Un GROS coup de gueule vs windows c'est de la merde ! Trop de télémétrie, de surveillance et autre !!! Sans parler des applis en fond qui ralentisse tout ton système !!! Dons ici sur windows pas icones personnalisés pour le pack outils dites merci à windows les antis vrais artistes et créatifs... Ils ne pensent que à se mettre de la tune dans les poches !!! Sans se foutre un minimum de vous leur utilisateur de leurs services par défaut !!!
Merde ouvrez les yeux et passer a Linux c'est libre ! Open source ! Ouvert a tout et tous... C'est gratuit !!! Et vraiment open à tout le monde !

---


> 🛠️ Forge audio libre signée Teknoïde 734 — à utiliser sans modération...  
> …et maintenant, même sous Windows, les runes s'activent 🛡️🎧🔥

> Forge audio libre signée Teknoïde 734 — à utiliser sans modération… > … sauf sur Windows. > Parce que là-bas, tout est enregistré 😈⚔️🔥
