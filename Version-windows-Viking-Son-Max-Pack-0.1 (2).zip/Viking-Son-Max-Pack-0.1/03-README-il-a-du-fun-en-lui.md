# ⚔️ Viking Son Max Pack 0.1  
**Forge audio libre signée Teknoïde 734 🛠️🔥⚔️**  
**Version multiplateforme – Linux + Escargot-Windows 11 🐌**

---

> ⚖️ Licence : MIT pour le code (`LICENSE`)  
> 🧠 + Clause complémentaire de respect créatif (`LICENSE-ET-RESPECT.md`)  
> Le code est libre. Le style est sacré.

---

Bienvenue dans la forge.  
Entre deux raids en Drakkar sur les routes du son, on a pondu ça ⚔️🔥⚔️  
Ici, on ne compresse pas : on extrait.  
On ne manipule pas des clics — on sculpte le son avec une hache.

---

## 🛠️ Qu’est-ce que c’est ?

Le pack Viking Son Max contient deux outils audio portables, désormais disponibles en `.sh` **ET** en `.bat` – pour affronter toutes les plateformes comme un vrai barbare éclairé.

### 🔉 Modules inclus :

- **Viking-Extracteur-Max** → extrait la bande-son d’une vidéo en `.wav` qualité HD-berserker  
- **Viking-Séparateur-Max** → sépare voix et musique d’un fichier `.wav`, via Demucs

> Aucun installateur. Aucun wizard. Aucun regret.  
> Décompressez, double-cliquez, découpez.  
> Pas de dépendances lourdes, pas de galère.  
> Juste du son. Du style. Et du terminal. 🔥

---

## 📦 Contenu rapide

- `🎧-Guide-de-lancement-et-activation-...md` → Toutes les commandes utiles, bien décrites
- `.sh` / `.bat` → Scripts bruts, puissants, terminal ready
- `.desktop` / `.lnk` → Lanceurs visuels avec icônes `.ico` intégrées

---

## 🔧 Dépendances minimales

| Plateforme | Nécessaire |
|------------|------------|
| **Linux** | FFmpeg complet + Python + venv + Demucs |
| **Windows** | `ffmpeg.exe` + Demucs intégré dans le pack |

💡 Tu n’as pas besoin d’être un dev nordique : tout est guidé dans `INSTALL.md`.

---

## ✅ À faire dès le début

### 🐧 Sous Linux

```bash
~$ chmod +x 00-FIXER-ICONES-VIKING.sh
~$ ./00-FIXER-ICONES-VIKING.sh
```

➡️ Corrige les chemins `Icon=` dans `.desktop`, copie les lanceurs dans le menu et applique les icônes avec `gio`.

---

Un GROS coup de gueule vs windows c'est de la merde ! Trop de télémétrie, de surveillance et autre !!! Sans parler des applis en fond qui ralentisse tout ton système !!! Dons ici sur windows pas icones personnalisés pour le pack outils dites merci à windows les antis vrais artistes et créatifs... Ils ne pensent que à se mettre de la tune dans les poches !!! Sans se foutre un minimum de vous leur utilisateur de leurs services par défaut !!!
Merde ouvrez les yeux et passer a Linux c'est libre ! Open source ! Ouvert a tout et tous... C'est gratuit !!! Et vraiment open à tout le monde !

---

## 📂 Lancement des outils

### 🐧 Linux :

```bash
~$ bash Viking-Extracteur-Max-0.1/ZX-.../Viking-Extracteur-Max.sh
~$ bash Viking-Separateur-Max-0.1/ZX-.../Viking-Separateur-Max.sh
```

### 🪟 Windows :

Double-clique :

- `🛠️ Lanceur-Viking-Extracteur-Max.lnk`
- `⚔️ Lanceur-Viking-Separateur-Max.lnk`

Ou lance manuellement via `cmd.exe` :

```cmd
call ZX-Viking-Extracteur-Max-0.1\Viking-Extracteur-Max.bat
call ZX-Viking-Separateur-Max-0.1-Script\Viking-Separateur-Max.bat
```

---

## ⚙️ Configuration personnalisée (facultatif)

Fichier : `config-viking.conf` *(utilisé uniquement côté Linux)*

```bash
# DEMUCS_VENV_PATH="/chemin/vers/ton/env-demucs"
```

ℹ️ Les `.bat` sur Windows sont déjà calibrés → aucune configuration nécessaire.

---

## ⚠️ Ajustements système possibles

| Système | Ajustement conseillé |
|--------|----------------------|
| Linux | `chmod +x` sur les `.sh` & `.desktop`, installer Nemo |
| Windows | Exécuter `.bat` en double-clic, ou terminal (`cmd`), pas besoin d’admin |

---

## 🍎 Et sur macOS ?

Installe FFmpeg avec Homebrew :

```bash
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
brew install ffmpeg
```

Crée un venv Python → installe Demucs → lance `.sh` comme sur Linux.

⚠️ `.desktop` non supportés. ✅ `.sh` = OK avec Terminal ou script Automator.

---

## 💬 L’auteur

> Scripts codés avec amour, humour et titane par Teknoïde 734  
> À utiliser librement, tant que tu respectes :  
> ⚙️ l’esprit DIY, 🔊 le son brut, 🔒 la non-domestication des runes
---

> Forge audio libre signée Teknoïde 734 — à utiliser sans modération… > … sauf sur Windows. > Parce que là-bas, tout est enregistré 😈⚔️🔥

