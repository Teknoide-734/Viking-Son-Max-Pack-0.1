# ⚙️ INSTALLATION — Viking Son Max Pack 0.1  
**Édition multiplateforme – Linux & Escargot-Windows** 🐧🐌  

Bienvenue dans la salle des outils.  
Avant de brandir les scripts audio, voici comment préparer ton terrain — que tu sois sur **Zorin**, **Ubuntu**, **Windows 11** ou **dans une grotte connectée** 🔧⚔️  

---

## 🔧 Dépendances nécessaires

### 🐧 Sous GNU/Linux

#### 1. FFmpeg — L’enclume de tout bon outil audio/vidéo
```bash
sudo apt install ffmpeg
```

💡 Si certaines fonctions semblent absentes, vérifie que tu n’as pas une version bridée.  
Test rapide :
```bash
ffmpeg -version
```

---

#### 2. Python + Demucs (pour séparer les pistes)
```bash
sudo apt install python3 python3-venv python3-pip
python3 -m venv ~/demucs-env
source ~/demucs-env/bin/activate
pip install -U demucs
```

Quitter le venv :
```bash
deactivate
```

---

#### 3. (Facultatif) Nemo pour une meilleure UX

```bash
sudo apt install nemo
```

Double-clique ensuite dans l’explorateur sur :

- 🛠️ Lanceur-Viking-Extracteur-Max.sh  
- ⚔️ Lanceur-Viking-Separateur-Max.sh

🎧 Et le son s’envole.

---

## 🪟 Sous Windows Escargot 11 Pro ou autre

💥 Aucune installation système requise.  
Tout est **embarqué dans le pack** :

- `ffmpeg.exe` déjà disponible
- Demucs intégré dans le dossier `Viking-Separateur-Max`
- Scripts `.bat` + raccourcis `.lnk` + `.ico` prêts à cliquer

### ✅ Étape 1 — Activer les icônes

ET NON RALLEz APRÈS microsoft et leur merde de windows c'est leur fautre pas sa sur cette version !
---

### ✅ Étape 2 — Lancer les outils

Via `.lnk` :

- Double-clic sur 🛠️ ou ⚔️ depuis le dossier racine  
- Terminal s’ouvre, exécution stylée

Ou via terminal `cmd` :

```cmd
cd /d Chemin\Vers\Viking-Son-Max-Pack-0.1
call ZX-Viking-Extracteur-Max-0.1\Viking-Extracteur-Max.bat
```

---

## 🗂️ Fichier de configuration (facultatif - uniquement Linux)

Fichier : `config-viking.conf`

```bash
# DEMUCS_VENV_PATH="/chemin/vers/ton/env-demucs"
```

ℹ️ Sur Windows, pas besoin : tout est calibré via chemins relatifs dans les `.bat`

---

## 📌 Note importante pour exécuter les commandes

### 🐧 Linux :
```bash
cd /chemin/vers/Viking-Son-Max-Pack-0.1
bash ./Viking-Extracteur-Max-0.1/...
```

### 🪟 Windows :
```cmd
cd /d Viking-Son-Max-Pack-0.1
call .\ZX-Viking-Extracteur-Max-0.1\Viking-Extracteur-Max.bat
```

✔️ Toujours se placer dans le dossier du pack pour éviter les erreurs de chemin.

---

## ⚙️ Ajustements système potentiels

| Plateforme  | Possibles ajustements                                                                 |
|-------------|---------------------------------------------------------------------------------------|
| Linux/macOS | `chmod +x`, Nemo recommandé                                                           |
| Windows     | Exécution `.bat` simple, parfois “Exécuter en tant qu’administrateur” si restrictions |

---

## 🧩 Activation des scripts & lanceurs

Tout est détaillé ici :  
📂 `🎧-Guide-de-lancement-et-activation-Viking-Son-Max-Pack-0.1.md`

---

💬 En cas de doute : un terminal, du courage, une hache à la main...  
Et une bonne playlist de black metal atmosphérique pour sanctifier le `.wav`.
---

Un GROS coup de gueule vs windows c'est de la merde ! Trop de télémétrie, de surveillance et autre !!! Sans parler des applis en fond qui ralentisse tout ton système !!! Dons ici sur windows pas icones personnalisés pour le pack outils dites merci à windows les antis vrais artistes et créatifs... Ils ne pensent que à se mettre de la tune dans les poches !!! Sans se foutre un minimum de vous leur utilisateur de leurs services par défaut !!!
Merde ouvrez les yeux et passer a Linux c'est libre ! Open source ! Ouvert a tout et tous... C'est gratuit !!! Et vraiment open à tout le monde !

---

> Forge audio libre signée Teknoïde 734 — à utiliser sans modération, sauf sur Windows 😈️⚔️🔥⚔️😈️

